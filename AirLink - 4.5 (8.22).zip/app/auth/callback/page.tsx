'use client'
import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabaseClient'

export default function AuthCallback() {
  const router = useRouter()
  useEffect(() => {
    (async () => {
      await supabase.auth.exchangeCodeForSession(window.location.href)
      router.replace('/onboarding/choose-role')
    })()
  }, [router])
  return <div className="section"><div className="max-w-md mx-auto">Finishing sign-in…</div></div>
}
