'use client';

import React from 'react';
import { AppProvider } from '@/lib/state'; // if your context file has a different path or name, adjust this import

export default function Providers({ children }: { children: React.ReactNode }) {
  return <AppProvider>{children}</AppProvider>;
}
