'use client'

import { FormEvent, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'
import { useRouter } from 'next/navigation'

export default function SignUpPage() {
  const router = useRouter()

  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [showPw, setShowPw] = useState(false)

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)

  const pwMismatch = password.length > 0 && confirm.length > 0 && password !== confirm

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null); setMessage(null)

    if (pwMismatch) {
      setError('Passwords do not match.')
      return
    }

    setLoading(true)
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { fullName },
          // 👇 makes the email confirmation link return to YOUR app, not localhost
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })
      if (error) throw error

      // If email confirmations are OFF, we already have a session now.
      if (data.session && data.user) {
        await supabase.from('profiles')
          .upsert({ id: data.user.id, full_name: fullName }, { onConflict: 'id' })
        router.push('/onboarding/choose-role')
        return
      }

      // If confirmations are ON, tell the user to check email
      setMessage('Check your email to confirm your account, then return here to sign in.')
    } catch (err: any) {
      setError(err.message ?? 'Sign up failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <section className="section">
      <div className="max-w-md mx-auto card p-6 space-y-4">
        <h1 className="text-2xl font-bold text-ink">Create your account</h1>

        <form onSubmit={onSubmit} className="space-y-3">
          <div>
            <label className="label">Full name</label>
            <input
              className="input w-full"
              value={fullName}
              onChange={e=>setFullName(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="label">Email</label>
            <input
              type="email"
              className="input w-full"
              value={email}
              onChange={e=>setEmail(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="label">Password</label>
            <div className="relative">
              <input
                type={showPw ? 'text' : 'password'}
                className="input w-full pr-16"
                value={password}
                onChange={e=>setPassword(e.target.value)}
                required
                minLength={6}
              />
              <button
                type="button"
                className="absolute right-2 top-1/2 -translate-y-1/2 text-sm underline"
                onClick={()=>setShowPw(s=>!s)}
              >
                {showPw ? 'Hide' : 'View'}
              </button>
            </div>
            <p className="text-xs text-slate-500 mt-1">Use at least 6 characters.</p>
          </div>

          <div>
            <label className="label">Confirm password</label>
            <input
              type={showPw ? 'text' : 'password'}
              className={`input w-full ${pwMismatch ? 'border-rose-300 ring-rose-300' : ''}`}
              value={confirm}
              onChange={e=>setConfirm(e.target.value)}
              required
              minLength={6}
            />
            {pwMismatch && <p className="text-rose-600 text-xs mt-1">Passwords do not match.</p>}
          </div>

          <button className="btn-primary w-full" disabled={loading || pwMismatch}>
            {loading ? 'Creating account...' : 'Sign up'}
          </button>
        </form>

        {error && <p className="text-rose-600 text-sm">{error}</p>}
        {message && <p className="text-emerald-700 text-sm">{message}</p>}

        <p className="text-sm text-slate-600">
          Already have an account? <a className="link" href="/sign-in">Sign in</a>
        </p>
      </div>
    </section>
  )
}
