// components/TagInput.tsx
'use client'
import React, { useEffect, useMemo, useState } from 'react'

type Props = {
  values?: string[] | string | null
  onChange: (vals: string[]) => void
  placeholder?: string
  allowComma?: boolean
  allowEnter?: boolean
  inputMode?: React.HTMLAttributes<HTMLInputElement>['inputMode']
  validate?: (v: string) => string | null // return error string or null if OK
  className?: string
  err?: boolean
}

export default function TagInput({
  values,
  onChange,
  placeholder = 'Type and press Enter…',
  allowComma = false,
  allowEnter = true,
  inputMode,
  validate,
  className = '',
  err = false,
}: Props) {
  // Coerce to array for rendering (handles old drafts that stored a string)
  const list = useMemo<string[]>(() => {
    if (Array.isArray(values)) return values.filter(Boolean).map(String)
    if (typeof values === 'string')
      return values
        .split(',')
        .map(s => s.trim())
        .filter(Boolean)
    return []
  }, [values])

  const [text, setText] = useState('')
  const [errMsg, setErrMsg] = useState<string | null>(null)

  useEffect(() => { if (err) setErrMsg(null) }, [err])

  function commitToken(raw: string) {
    const v = raw.trim()
    if (!v) return
    const e = validate?.(v) ?? null
    if (e) { setErrMsg(e); return }
    setErrMsg(null)
    if (!list.includes(v)) onChange([...list, v])
    setText('')
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    // Enter to commit
    if (allowEnter && e.key === 'Enter') {
      e.preventDefault()
      commitToken(text)
      return
    }
    // Backspace to remove last chip if empty
    if (e.key === 'Backspace' && !text && list.length) {
      e.preventDefault()
      const next = [...list]
      next.pop()
      onChange(next)
      return
    }
  }

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const v = e.target.value
    if (allowComma && v.includes(',')) {
      // Split on commas, commit each, keep last partial
      const parts = v.split(',')
      const last = parts.pop() ?? ''
      parts.forEach(p => commitToken(p))
      setText(last)
    } else {
      setText(v)
    }
  }

  function removeAt(i: number) {
    const next = [...list]
    next.splice(i, 1)
    onChange(next)
  }

  function handleBlur() {
    // Commit pending text on blur
    if (text.trim()) commitToken(text)
  }

  return (
    <div className={`rounded-xl border p-2 ${err ? 'border-rose-300 ring-rose-300' : 'border-slate-200'} ${className}`}>
      <div className="flex flex-wrap items-center gap-2">
        {list.map((v, i) => (
          <span
            key={`${v}-${i}`}
            className="inline-flex items-center gap-1 rounded-lg border border-emerald-500 bg-emerald-50 px-2 py-1 text-xs text-emerald-800"
          >
            {v}
            <button
              type="button"
              className="ml-1 rounded px-1 text-emerald-700/80 hover:bg-emerald-100"
              onClick={() => removeAt(i)}
              aria-label={`Remove ${v}`}
            >
              ✕
            </button>
          </span>
        ))}

        <input
          className="min-w-[120px] flex-1 bg-transparent outline-none text-sm px-2 py-1"
          value={text}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          onBlur={handleBlur}
          placeholder={placeholder}
          inputMode={inputMode}
        />
      </div>
      {errMsg && <div className="mt-1 text-[11px] text-rose-600">{errMsg}</div>}
    </div>
  )
}
