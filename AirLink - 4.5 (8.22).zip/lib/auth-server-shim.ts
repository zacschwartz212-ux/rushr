export async function getServerSession(..._args: any[]) {
  return null;
}
